import tkinter as tk
import qrcode
from PIL import ImageTk, Image

# Function to generate QR code from the input link
def generate_qr_code():
    link = entry.get()  # Get the link from the entry field
    if link:
        # Generate the QR code
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(link)
        qr.make(fit=True)
        
        # Create an image from the QR code
        img = qr.make_image(fill='black', back_color='white')
        
        # Convert the image to a format that Tkinter can use
        img = img.resize((200, 200))  # Resize for better display
        img_tk = ImageTk.PhotoImage(img)
        
        # Display the QR code image in the window
        qr_label.config(image=img_tk)
        qr_label.image = img_tk  # Keep a reference to the image
    else:
        result_label.config(text="Please enter a valid link.")

# Create the main window
window = tk.Tk()
window.title("QR Code Generator")
window.geometry("300x350")

# Create a label for the instructions
label = tk.Label(window, text="Enter a URL to generate QR Code:", font=("Arial", 12))
label.pack(pady=10)

# Create an entry widget for the link input
entry = tk.Entry(window, font=("Arial", 12), width=30)
entry.pack(pady=10)

# Create a button to generate the QR code
generate_button = tk.Button(window, text="Generate QR Code", font=("Arial", 12), command=generate_qr_code)
generate_button.pack(pady=10)

# Create a label to display the QR code
qr_label = tk.Label(window)
qr_label.pack(pady=10)

# Create a label to show results or errors
result_label = tk.Label(window, font=("Arial", 10))
result_label.pack(pady=10)

# Run the Tkinter event loop
window.mainloop()
